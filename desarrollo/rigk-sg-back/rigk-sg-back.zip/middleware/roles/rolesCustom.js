"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.verifyRolProductor = void 0;
const VerifyProductor_1 = require("./VerifyProductor");
Object.defineProperty(exports, "verifyRolProductor", { enumerable: true, get: function () { return VerifyProductor_1.verifyRolProductor; } });
