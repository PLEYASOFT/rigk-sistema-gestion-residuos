"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.updateStateScheme = exports.statementByIdScheme = exports.statementProductorFormScheme = void 0;
const joi_1 = __importDefault(require("joi"));
exports.statementProductorFormScheme = joi_1.default.object({
    header: joi_1.default.object({
        id_business: joi_1.default.number()
            .required(),
        year_statement: joi_1.default.number()
            .min(1000)
            .max(9999)
            .required(),
        state: joi_1.default.boolean(),
        id_statement: joi_1.default.number().allow(null)
    }),
    detail: joi_1.default.array().has(joi_1.default.object({
        precedence: joi_1.default.number()
            .required(),
        hazard: joi_1.default.number()
            .required(),
        recyclability: joi_1.default.number()
            .required(),
        type_residue: joi_1.default.number()
            .required(),
        value: joi_1.default.number()
            .required(),
        amount: joi_1.default.number().required(),
        id: joi_1.default.number().allow(null),
        id_header: joi_1.default.number().allow(null)
    })),
});
exports.statementByIdScheme = joi_1.default.object({
    business: joi_1.default.number()
        .required(),
    draft: joi_1.default.number().required(),
    year: joi_1.default.number()
        .min(1000)
        .max(9999)
        .required()
});
exports.updateStateScheme = joi_1.default.object({
    id: joi_1.default.number()
        .required(),
    state: joi_1.default.boolean()
        .required()
});
