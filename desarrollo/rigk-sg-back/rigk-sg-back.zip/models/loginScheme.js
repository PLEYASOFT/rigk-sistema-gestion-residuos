"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.recoveryPasswordScheme = exports.modifyPasswordScheme = exports.loginScheme = void 0;
const joi_1 = __importDefault(require("joi"));
exports.loginScheme = joi_1.default.object({
    user: joi_1.default.string().email({ minDomainSegments: 2, tlds: { allow: ['com', 'net', 'cl'] } }).required(),
    password: joi_1.default.string()
        .pattern(new RegExp('^[a-zA-Z0-9]{8,30}$')).required()
});
exports.modifyPasswordScheme = joi_1.default.object({
    newPassword: joi_1.default.string().min(8).pattern(new RegExp('^[a-zA-Z0-9]{8,30}$')).required(),
    actual: joi_1.default.string().min(8).pattern(new RegExp('^[a-zA-Z0-9]{8,30}$')).required(),
    repeatPassword: joi_1.default.string().min(8).pattern(new RegExp('^[a-zA-Z0-9]{8,30}$')).required()
});
exports.recoveryPasswordScheme = joi_1.default.object({
    user: joi_1.default.string().email({ minDomainSegments: 2, tlds: { allow: ['com', 'net', 'cl'] } }).required(),
    password: joi_1.default.string().min(8).pattern(new RegExp('^[a-zA-Z0-9]{8,30}$')).required(),
    repeatPassword: joi_1.default.string().min(8).pattern(new RegExp('^[a-zA-Z0-9]{8,30}$')).required()
});
