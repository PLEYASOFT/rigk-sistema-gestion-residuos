"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const authLogic_1 = __importDefault(require("../controllers/authLogic"));
const validar_jwt_1 = require("../middleware/validar-jwt");
const validateLogin_1 = require("../middleware/validateLogin");
const modifyPassword_1 = require("../middleware/validators/modifyPassword");
const recoveyPassword_1 = require("../middleware/validators/recoveyPassword");
const router = (0, express_1.Router)();
router.post('/', [validateLogin_1.validateLogin], authLogic_1.default.login);
router.post('/modifyPassword', [validar_jwt_1.validarJWT, modifyPassword_1.verifyParametersModifyPassword], authLogic_1.default.modifyPassword);
router.post('/sendCode', [], authLogic_1.default.sendCode);
router.post('/sendCode/verify', [], authLogic_1.default.sendCodeVerify);
router.post('/sendCode/recovery', [recoveyPassword_1.recoveryPassword], authLogic_1.default.recoveryPassword);
router.post('/register', [], authLogic_1.default.register);
exports.default = router;
