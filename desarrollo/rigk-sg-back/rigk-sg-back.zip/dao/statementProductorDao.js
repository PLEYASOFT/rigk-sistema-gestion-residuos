"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const db_1 = __importDefault(require("../db"));
class statementProductorDao {
    getDeclaretionsByUser(user) {
        return __awaiter(this, void 0, void 0, function* () {
            const conn = db_1.default.getConnection();
            const statements = yield (conn === null || conn === void 0 ? void 0 : conn.execute("SELECT * FROM header_statement_form WHERE CREATED_BY = ?", [user]).then((res) => res[0]).catch(error => { undefined; }));
            conn === null || conn === void 0 ? void 0 : conn.end();
            return { statements };
        });
    }
    getDeclaretionByYear(business, year, isDraft) {
        return __awaiter(this, void 0, void 0, function* () {
            let res_header;
            let res_detail;
            const conn = db_1.default.getConnection();
            const res_business = yield (conn === null || conn === void 0 ? void 0 : conn.execute("SELECT * FROM business WHERE ID = ?", [business]).then((res) => res[0]).catch(error => { undefined; }));
            if (res_business.length == 0) {
                return false;
            }
            res_header = yield (conn === null || conn === void 0 ? void 0 : conn.execute("SELECT * FROM header_statement_form WHERE ID_BUSINESS = ? AND YEAR_STATEMENT = ? AND STATE = ? ORDER BY ID DESC", [business, year, Math.abs(isDraft - 1)]).then((res) => res[0]).catch(error => { undefined; }));
            if (res_header.length == 0) {
                return false;
            }
            const id_statement = res_header[0].ID;
            res_detail = yield (conn === null || conn === void 0 ? void 0 : conn.execute("SELECT * FROM detail_statement_form WHERE ID_HEADER = ?", [id_statement]).then((res) => res[0]).catch(error => { undefined; }));
            conn === null || conn === void 0 ? void 0 : conn.end();
            return { header: res_header[0], detail: res_detail };
        });
    }
    saveDeclaretion(header, detail) {
        return __awaiter(this, void 0, void 0, function* () {
            const { id_business, year_statement, state, created_by } = header;
            const conn = db_1.default.getConnection();
            let id_header = 0;
            if (header.id_statement) {
                id_header = header.id_statement;
            }
            else {
                const resp = yield (conn === null || conn === void 0 ? void 0 : conn.execute("INSERT INTO header_statement_form(ID_BUSINESS,YEAR_STATEMENT,STATE,CREATED_BY) VALUES (?,?,?,?)", [id_business, year_statement, state, created_by]).then(res => res[0]).catch(error => { console.log(error); }));
                id_header = resp.insertId;
            }
            for (let i = 0; i < detail.length; i++) {
                const { precedence, hazard, recyclability, type_residue, value, amount } = detail[i];
                if (detail[i].id) {
                    yield (conn === null || conn === void 0 ? void 0 : conn.execute("UPDATE detail_statement_form SET VALUE = ? WHERE ID=?", [value, detail[i].id]));
                }
                else {
                    yield (conn === null || conn === void 0 ? void 0 : conn.execute("INSERT INTO detail_statement_form(ID_HEADER,PRECEDENCE,HAZARD,RECYCLABILITY,TYPE_RESIDUE,VALUE, AMOUNT) VALUES (?,?,?,?,?,?,?)", [id_header, precedence, hazard, recyclability, type_residue, value, amount]).catch(err => console.log(err)));
                }
            }
            conn === null || conn === void 0 ? void 0 : conn.end();
            return { id_header: id_header };
        });
    }
    updateValueStatement(id_header, detail) {
        return __awaiter(this, void 0, void 0, function* () {
            const conn = db_1.default.getConnection();
            // await conn?.execute("UPDATE header_statement_form SET STATE = true WHERE id = ?", [id_header]).then((res) => res[0]).catch(error => undefined);
            for (let i = 0; i < detail.length; i++) {
                const { precedence, hazard, recyclability, type_residue, value, amount } = detail[i];
                if (detail[i].id) {
                    yield (conn === null || conn === void 0 ? void 0 : conn.execute("UPDATE detail_statement_form SET VALUE = ?, AMOUNT=? WHERE ID=?", [value, amount, detail[i].id]));
                }
                else {
                    yield (conn === null || conn === void 0 ? void 0 : conn.execute("INSERT INTO detail_statement_form(ID_HEADER,PRECEDENCE,HAZARD,RECYCLABILITY,TYPE_RESIDUE,VALUE, AMOUNT) VALUES (?,?,?,?,?,?,?)", [id_header, precedence, hazard, recyclability, type_residue, value, amount]).catch(err => console.log(err)));
                }
            }
            conn === null || conn === void 0 ? void 0 : conn.end();
            return;
        });
    }
    changeStateHeader(state, id) {
        return __awaiter(this, void 0, void 0, function* () {
            const conn = db_1.default.getConnection();
            const tmp = yield (conn === null || conn === void 0 ? void 0 : conn.execute("UPDATE header_statement_form SET STATE = ? WHERE id = ?", [state, id]).then((res) => res[0]).catch(error => undefined));
            if (tmp == undefined) {
                return false;
            }
            conn === null || conn === void 0 ? void 0 : conn.end();
            return true;
        });
    }
    haveDraft(business, year) {
        return __awaiter(this, void 0, void 0, function* () {
            const conn = db_1.default.getConnection();
            const res = yield (conn === null || conn === void 0 ? void 0 : conn.execute("SELECT id FROM header_statement_form WHERE ID_BUSINESS=? AND YEAR_STATEMENT=? AND STATE=1 ORDER BY ID DESC LIMIT 1", [business, year]).then((res) => res[0]).catch(error => undefined));
            let isOk = false;
            if (res != null && res != undefined && res.length > 0) {
                isOk = true;
                conn === null || conn === void 0 ? void 0 : conn.end();
                return isOk;
            }
            else {
                conn === null || conn === void 0 ? void 0 : conn.end();
                return isOk;
            }
        });
    }
}
const statementDao = new statementProductorDao();
exports.default = statementDao;
