"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const db_1 = __importDefault(require("../db"));
class AuthDao {
    getPassword(ID) {
        return __awaiter(this, void 0, void 0, function* () {
            const conn = db_1.default.getConnection();
            const res_passwd = yield conn.query("SELECT PASSWORD, SALT FROM USER WHERE ID = ?", [ID]).then((res) => res[0]).catch(error => [{ undefined }]);
            conn.end();
            return res_passwd[0];
        });
    }
    updatePassword(PASSWORD, USER) {
        return __awaiter(this, void 0, void 0, function* () {
            const conn = db_1.default.getConnection();
            const res = yield conn.query("UPDATE USER SET PASSWORD = ? WHERE ID = ?", [PASSWORD, USER]).then((res) => res[0]).catch(error => [{ undefined }]);
            conn.end();
            return res;
        });
    }
    login(USER) {
        return __awaiter(this, void 0, void 0, function* () {
            const conn = db_1.default.getConnection();
            const res = yield conn.query("SELECT USER.*,USER_ROL.ROL_ID AS ROL, ROL.NAME AS ROL_NAME, BUSINESS.NAME AS BUSINESS FROM USER INNER JOIN USER_ROL ON USER_ROL.USER_ID = USER.ID INNER JOIN USER_BUSINESS ON USER_BUSINESS.ID_USER = USER.ID INNER JOIN BUSINESS ON BUSINESS.ID = USER_BUSINESS.ID_BUSINESS INNER JOIN ROL ON ROL.ID=USER_ROL.ROL_ID WHERE USER.EMAIL = ?", [USER]).then((res) => res[0]).catch(error => [{ undefined }]);
            console.log(res[0]);
            let login = false;
            if (res != null && res != undefined && res.length > 0) {
                login = true;
            }
            conn.end();
            return res[0] || undefined;
        });
    }
    verifyEmail(USER) {
        return __awaiter(this, void 0, void 0, function* () {
            const conn = db_1.default.getConnection();
            const res = yield conn.query("SELECT EMAIL,ID,PASSWORD FROM USER WHERE EMAIL = ?", [USER]).then((res) => res[0]).catch(error => [{ undefined }]);
            let login = false;
            conn.end();
            if (res != null && res != undefined && res.length > 0) {
                login = true;
                return res[0];
            }
            else {
                console.log("Correo no es correcto, intente nuevamente");
                return res;
            }
        });
    }
    generateCode(CODE, ID) {
        return __awaiter(this, void 0, void 0, function* () {
            const conn = db_1.default.getConnection();
            const now = new Date();
            const res = yield conn.query("UPDATE USER SET CODE = ?, DATE_CODE = ? WHERE ID=?", [CODE, now, ID]).then((res) => res[0]).catch(error => [{ undefined }]);
            conn.end();
            return res;
        });
    }
    verifyCode(CODE, USER) {
        return __awaiter(this, void 0, void 0, function* () {
            const conn = db_1.default.getConnection();
            const res = yield conn.query("SELECT CODE,DATE_CODE,ID FROM USER WHERE CODE = ? AND EMAIL =?", [CODE, USER]).then((res) => res[0]).catch(error => [{ undefined }]);
            conn.end();
            let login = false;
            if (res != null && res != undefined && res.length > 0) {
                login = true;
                return res[0];
            }
            else {
                console.log("Código incorrecto, intente nuevamente");
                return res;
            }
        });
    }
    recovery(PASSWORD, USER) {
        return __awaiter(this, void 0, void 0, function* () {
            const conn = db_1.default.getConnection();
            const res = yield conn.query("UPDATE USER SET PASSWORD = ? WHERE EMAIL = ?", [PASSWORD, USER]).then((res) => res[0]).catch(error => [{ undefined }]);
            conn.end();
            return res;
        });
    }
    register(EMAIL, FIRST_NAME, LAST_NAME, PASSWORD, PHONE) {
        return __awaiter(this, void 0, void 0, function* () {
            const conn = db_1.default.getConnection();
            const res = yield conn.query("INSERT INTO user(EMAIL,FIRST_NAME,LAST_NAME, PASSWORD,PHONE, STATE, SALT) VALUES (?,?,?,?,?,?,'ABC')", [EMAIL, FIRST_NAME, LAST_NAME, PASSWORD, PHONE, 1]).then((res) => res[0]).catch(error => [{ undefined }]);
            const res_1 = yield conn.query("INSERT INTO user_rol(USER_ID,ROL_ID) VALUES (?,?)", [res.insertId]).then((res) => res[0]).catch(error => [{ undefined }]);
            conn.end();
            return res;
        });
    }
}
const authDao = new AuthDao();
exports.default = authDao;
