"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const ratesDao_1 = __importDefault(require("../dao/ratesDao"));
class RatesLogic {
    getRatesByYear(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            const { year } = req.params;
            try {
                const resp = yield ratesDao_1.default.ratesID(year);
                res.status(200).json({ status: true, data: resp, msg: 'ok' });
            }
            catch (err) {
                console.log(err);
                res.status(500).json({
                    status: false,
                    message: "Algo salió mal"
                });
            }
        });
    }
    getRatesCLP(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            const now = new Date();
            const date = now.toISOString().split("T")[0];
            const year = (now.getFullYear() + 1).toString();
            try {
                const uf = yield ratesDao_1.default.getUF(date);
                const rates_resp = yield ratesDao_1.default.ratesID(year);
                const resp = [];
                for (let i = 0; i < rates_resp.length; i++) {
                    const rate = rates_resp[i];
                    rate.clp = (rate.price * uf).toFixed(0);
                    resp.push(rate);
                }
                res.json({ status: true, data: resp });
            }
            catch (err) {
                console.log(err);
                res.status(500).json({
                    status: false,
                    message: "Algo salió mal"
                });
            }
        });
    }
    getUfDay(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            const now = new Date();
            const date = now.toISOString().split("T")[0];
            try {
                const uf = yield ratesDao_1.default.getUF(date);
                res.json({ status: true, data: uf });
            }
            catch (error) {
                console.log(error);
                res.status(500).json({
                    status: false,
                    message: "Algo salió mal"
                });
            }
        });
    }
}
const ratesLogic = new RatesLogic();
exports.default = ratesLogic;
