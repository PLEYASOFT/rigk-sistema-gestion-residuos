"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const bcrypt_1 = __importDefault(require("bcrypt"));
const jwt_1 = require("../helpers/jwt");
const sendCode_1 = require("../helpers/sendCode");
const authDao_1 = __importDefault(require("../dao/authDao"));
class AuthLogic {
    modifyPassword(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            const { newPassword, actual } = req.body;
            const repeatPassword = req.body.repeatPassword;
            const user = req.uid;
            try {
                if (newPassword !== repeatPassword) {
                    return res.status(200).json({ status: false, msg: 'contraseña no coincide', data: {} });
                }
                else if (newPassword == '' || repeatPassword == '') {
                    return res.status(200).json({ status: false, msg: 'ingrese una contraseña', data: {} });
                }
                else {
                    const output = yield authDao_1.default.getPassword(user);
                    bcrypt_1.default.compare(actual, output.PASSWORD).then((r) => __awaiter(this, void 0, void 0, function* () {
                        if (r) {
                            let passwordHash = bcrypt_1.default.hashSync(newPassword, 8);
                            const output2 = yield authDao_1.default.updatePassword(passwordHash, user);
                            res.status(200).json({ status: true, msg: 'Contraseña cambiada', data: {} });
                        }
                        else {
                            res.status(200).json({ status: false, msg: 'Contraseña incorrecta, intenta nuevamente', data: {} });
                        }
                    }));
                }
            }
            catch (err) {
                res.status(500).json({ status: false, msg: 'Ocurrió un error', data: {} });
            }
        });
    }
    login(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            const user = req.body.user;
            const password = req.body.password;
            try {
                const output = yield authDao_1.default.login(user);
                if (output != undefined) {
                    bcrypt_1.default.compare(password, output.PASSWORD).then((r) => __awaiter(this, void 0, void 0, function* () {
                        if (r) {
                            const token = yield (0, jwt_1.generarJWT)(output.ID, user, output.ROL);
                            delete output.PASSWORD;
                            delete output.SALT;
                            delete output.STATE;
                            delete output.DATE_CODE;
                            delete output.CODE;
                            delete output.ID;
                            res.header('x-token', token.toString());
                            res.header("Access-Control-Expose-Headers", "*");
                            res.status(200).json({ status: true, msg: '', data: { user: output } });
                        }
                        else {
                            res.status(200).json({ status: false, msg: 'Usuario y/o contraseña incorrectos, intenta nuevamente', data: {} });
                        }
                    }));
                }
                else {
                    res.status(200).json({ status: false, msg: 'Usuario y/o contraseña incorrectos, intenta nuevamente', data: {} });
                }
            }
            catch (err) {
                console.log(err);
                res.status(500).json({ status: false, msg: 'Ocurrió un error', data: {} });
            }
        });
    }
    sendCode(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            const { user } = req.body;
            try {
                const output = yield authDao_1.default.verifyEmail(user);
                if (output.EMAIL == user) {
                    const cod = (Math.random() * (999999 - 100000) + 100000).toFixed(0);
                    yield authDao_1.default.generateCode(cod, output.ID);
                    (0, sendCode_1.sendCode)(output, cod, res);
                    res.status(200).json({ status: true, msg: '', data: output.EMAIL });
                }
                else {
                    res.status(200).json({ status: false, msg: 'Correo no registrado', data: {} });
                }
            }
            catch (err) {
                console.log(err);
                res.status(500).json({ status: false, msg: 'Ocurrió un error', data: {} });
            }
        });
    }
    sendCodeVerify(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            const code = req.body.code;
            const { user } = req.body;
            try {
                const output = yield authDao_1.default.verifyCode(code, user);
                if (output.CODE == code) {
                    const now = new Date().getTime();
                    const dateCode = new Date(output.DATE_CODE).getTime();
                    const dif2 = ((now - dateCode) / (60000));
                    if (dif2 <= 5) {
                        res.status(200).json({ status: true, msg: 'Código correcto, modifique contraseña', data: {} });
                    }
                    else {
                        res.status(200).json({ status: false, msg: 'Código expirado, solicitelo nuevamente', data: {} });
                    }
                }
                else {
                    res.status(200).json({ status: false, msg: 'Código incorrecto', data: {} });
                }
            }
            catch (err) {
                console.log(err);
                res.status(500).json({ status: false, msg: 'Ocurrió un error', data: {} });
            }
        });
    }
    recoveryPassword(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            const user = req.body.user;
            const password = req.body.password;
            const repeatPassword = req.body.repeatPassword;
            try {
                if (password !== repeatPassword) {
                    return res.status(200).json({ status: false, msg: 'contraseña no coincide', data: {} });
                }
                else if (password == '' || repeatPassword == '') {
                    res.status(200).json({ status: false, msg: 'Contraseña vacía', data: {} });
                }
                else {
                    let passwordHash = bcrypt_1.default.hashSync(password, 8);
                    yield authDao_1.default.recovery(passwordHash, user);
                    res.status(200).json({ status: true, msg: 'Haz recuperado tu contraseña', data: {} });
                }
            }
            catch (err) {
                console.log(err);
                res.status(500).json({ status: false, msg: 'Ocurrió un error', data: {} });
            }
        });
    }
    register(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            const user = req.body.user;
            const first_name = req.body.first_name;
            const last_name = req.body.last_name;
            const password = req.body.password;
            const phone = req.body.phone;
            try {
                let passwordHash = bcrypt_1.default.hashSync(password, 8);
                const result = yield authDao_1.default.register(user, first_name, last_name, passwordHash, phone);
                res.status(200).json({ status: true, msg: 'Has creado usuario', data: {} });
            }
            catch (err) {
                console.log(err);
                res.status(500).json({ status: false, msg: 'Ocurrió un error', data: {} });
            }
        });
    }
}
const authLogic = new AuthLogic();
exports.default = authLogic;
