"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.sendCode = void 0;
const nodemailer_1 = __importDefault(require("nodemailer"));
const db_1 = __importDefault(require("../db"));
const sendCode = (output, cod, res) => __awaiter(void 0, void 0, void 0, function* () {
    const transporter = nodemailer_1.default.createTransport({
        pool: true,
        host: "mail.prorep.cl",
        port: 465,
        secure: true,
        auth: {
            user: `${process.env.EMAIL_ADDRESS}`,
            pass: `${process.env.EMAIL_PASSWORD}`,
        }
    });
    const conn = db_1.default.getConnection();
    const result = yield conn.query("SELECT FIRST_NAME,LAST_NAME FROM USER WHERE EMAIL =?", [output.EMAIL]).then((res) => res[0]).catch(error => [{ undefined }]);
    console.log(result);
    const mailOptions = {
        from: `PROREP noreply@prorep.cl`,
        to: `${output.EMAIL}`,
        subject: 'Código de recuperación',
        text: `${result[0].FIRST_NAME} ${result[0].LAST_NAME}, el código para la recuperación de su contraseña es:\n\n${cod}\n\nSaludos,\n\nEquipo PROREP\n\nPor favor, no responda a este email. Para más información, escriba a info@prorep.cl`
    };
    transporter.sendMail(mailOptions, (err, response) => {
        if (err) {
            console.error('Ha ocurrido un error:', err);
        }
        else {
            console.log('Respuesta:', response);
            res.status(200).json('El email para la recuperación ha sido enviado');
        }
    });
});
exports.sendCode = sendCode;
